import java.io.Serializable;

public class Developer implements Serializable{
	String DeveloperName, gender;
	String DeveloperId;
	Address add;
	project p;
	
Developer(String DeveloperName, String gender, String DeveloperId, Address add, project p){
	this.DeveloperName=DeveloperName;
	this.gender=gender;
	this.DeveloperId=DeveloperId; 	
	this.add=add;
	this.p=p;
	
}//close developer constructor

public String getDeveloperName(){
	return this.DeveloperName=DeveloperName;
}//close get method

public String getgender(){
	return this.gender=gender;
}
public String getDeveloperId(){
	return this.DeveloperId=DeveloperId;
}
public void setDeveloperName(String DeveloperName){
	this.DeveloperName=DeveloperName;
	
}//close set method
public void setgender(String gender){
	this.gender=gender;
	
}//close set method
public void setDeveloperId(String DeveloperId){
	this.DeveloperId=DeveloperId;
	
}//close set method
public void editClientName(String cName){
	this.p.setclientName(cName);
}
}//close class