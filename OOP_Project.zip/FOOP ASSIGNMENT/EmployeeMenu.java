//Main Menu Function 
//Declaring Function
import java.util.Scanner;
import java.time.LocalDate;
import java.io.Serializable;
import java.io.*;
//Menu Class
//Variables Declaration
public class EmployeeMenu{ 
	public static int choice=0, num=0, choice1=0, choiceM=0, editFTC=0; 
	public static String DeveloperName, gender;
	public static double AnnualSalary, MaxNumOfHour, HourlyRate;
	public static String UnitNo, StreetName, city, postCode, projectID, clientName, cost, PrdEndDate, ActualEndDate, projectTxt, newDeveloperName, newclientName
	;
	public static String DeveloperID, reply, reply2, next="y";
	public static LocalDate startDate;
	static Scanner myObj = new Scanner(System.in);
	public static FullTimeDeveloper ft[]=new FullTimeDeveloper[50];
	public static int idx=0;



	public static void EnterFullTimeDet()throws Exception{
		do{
			next="Y";
			System.out.println("Enter Developer Name: ");
			DeveloperName= myObj.next();
			
			System.out.println("Enter Gender: ");
			gender=myObj.next();
			
			System.out.println("Enter ID: ");
			DeveloperID=myObj.next();
			
			System.out.println("Enter Annual Salary: ");
			AnnualSalary=myObj.nextDouble();
			
			System.out.println("Enter Unit No: ");
			UnitNo=myObj.next();
			
			System.out.println("Enter Street Name: ");
			StreetName=myObj.next();
			
			System.out.println("Enter City: ");
			city=myObj.next();
			
			System.out.println("Enter Postcode: ");
			postCode=myObj.next();
			
			System.out.println("Enter Project ID: ");
			projectID=myObj.next();
			
			System.out.println("Enter Client Name: ");
			clientName=myObj.next();
			
			System.out.println("Enter Cost: ");
			cost=myObj.next();
			
			System.out.println("Starting Date: ");
			LocalDate myObjDate=LocalDate.now();
			
			//System.out.println("Enter Project End Date: ");
			//LocalDate myObj=LocalDate.now();
			
			//System.out.println("Enter Project Actual End Date: ");
			//LocalDate myObj=LocalDate.now();
			
			System.out.println("Enter Project Details: ");
			projectTxt=myObj.next();
			
			System.out.println("Do you want to save the details: [Y/N] ");
			reply=myObj.next();
			
		if (reply.equals("Y") || reply.equals("y")) {
			SaveFullTimeRec();
			System.out.println("Details Have Been Saved :)");
			
			System.out.println("Do you want to enter another full time details: [Y/N] ");
			next=myObj.next();
			
		}	
		}while(next.equals("Y")||next.equals("y"));
	}//Enter full time details
	
	//SAVE FULLTIME REC
	public static void SaveFullTimeRec() throws Exception{
	Address add=new Address(UnitNo, StreetName, city, postCode);
	project p=new project(projectID, clientName, cost, startDate, projectTxt);
	ft[idx]=new FullTimeDeveloper(DeveloperName, DeveloperID, gender, AnnualSalary, add, p);
	idx++;
		
	}//Save full time 
	
		public static void ViewFullTimeLog() throws Exception{
			int i=0;
			for (i=0; i<idx; i++){
			System.out.println("Full Time Developer Name: " +ft[i].getDeveloperName());
			System.out.println("Full Time Developer Gender: " +ft[i].getgender());
			System.out.println("Full Time Developer ID: " +ft[i].getDeveloperId());
			System.out.println("Full Time Developer Annual Salary: " +ft[i].getAnnualSalary());
			ft[i].DisplayAddressDetails();
			ft[i].DisplayProjectDetails();
				
			}
			
			
		}//end ViewFullTimeLog
		
		public static void EnterPartTimeDet()throws Exception{
			System.out.println("Enter Developer Name: ");
			DeveloperName= myObj.next();
			
			System.out.println("Enter Gender: ");
			gender=myObj.next();
			
			System.out.println("Enter ID: ");
			DeveloperID=myObj.next();
			
			System.out.println("Enter Hourly Rate: ");
			HourlyRate=myObj.nextDouble();
			
			System.out.println("Enter Maximum Number Of Hours: ");
			MaxNumOfHour=myObj.nextDouble();
			
			System.out.println("Enter Street Name: ");
			StreetName=myObj.next();
			
			System.out.println("Enter City: ");
			city=myObj.next();
			
			System.out.println("Enter Postcode: ");
			postCode=myObj.next();
			
			System.out.println("Enter Project ID: ");
			projectID=myObj.next();
			
			System.out.println("Enter Client Name: ");
			clientName=myObj.next();
			
			System.out.println("Enter Cost: ");
			cost=myObj.next();
			
			System.out.println("Starting Date: ");
			LocalDate myObjDate=LocalDate.now();
			
			//System.out.println("Enter Project End Date: ");
			//LocalDate myObj=LocalDate.now();
			
			//System.out.println("Enter Project Actual End Date: ");
			//LocalDate myObj=LocalDate.now();
			
			System.out.println("Enter Project Details: ");
			projectTxt=myObj.next();
			
			System.out.println("Do you want to save the details: [Y/N] ");
			reply2=myObj.next();
			
		if (reply2.equals("Y") || reply2.equals("y")) {
			SavePartTimeRec();
			System.out.println("Details Have Been Saved :)");
		}	
	}//Enter full time details
	
	//SAVE PARTTIME REC
	public static void SavePartTimeRec() throws Exception{
	FileOutputStream pFile=new FileOutputStream(new File("PartTimers.txt"));
	ObjectOutputStream op=new ObjectOutputStream(pFile);
	Address parttimeAddress=new Address(UnitNo, StreetName, city, postCode);
	project parttimeProject=new project(projectID, clientName, cost, startDate, projectTxt);
	PartTimeDeveloper pt=new PartTimeDeveloper(DeveloperName, DeveloperID, gender, MaxNumOfHour, HourlyRate, parttimeAddress, parttimeProject);
	//Write Objects to file
	op.writeObject(pt);
	op.close();
	pFile.close();
	//PartTimeDeveloper ft=new PartTimeDeveloper()
		
	}
	
	
		
		public static void ViewPartTimeLog() throws Exception{
			FileInputStream fi=new FileInputStream(new File("PartTimers.txt"));
			ObjectInputStream oi=new ObjectInputStream(fi);
			PartTimeDeveloper ft =  (PartTimeDeveloper)oi.readObject();
			System.out.println("Part Time Developer Name: " +ft.getDeveloperName());
			System.out.println("Part Time Developer Gender: " +ft.getgender());
			System.out.println("Part Time Developer ID: " +ft.getDeveloperId());
			System.out.println("Part Time Developer Maximum Hours: " +ft.getMaxNumOfHour());
			ft.DisplayAddressDetails();
			ft.DisplayProjectDetails();
			oi.close();
			fi.close();
			
		}//end ViewFullTimeLog
		
		public static void ViewEmployeeLog() throws Exception{
		do{
		System.out.println("\t========================\n");
		System.out.println("\tView Employees Log\n");
		System.out.println("\t========================\n");
		System.out.println("\t [1]View Full Time Employee Log\n");
		System.out.println("\t [2]View Part Time Employee Log\n");
		System.out.println("\t [3]Return To Main Menu\n");
		
		//Enable user input
		Scanner myObj = new Scanner(System.in); 
		System.out.println("Enter Your Choice:");
		choice1 = myObj.nextInt();
		
		//Use Switch Case 
		switch(choice1){
			case 1:
			ViewFullTimeLog();
			break;
			
			case 2:
			ViewPartTimeLog();
			break;
			
			case 3:
			MainMenu();
			break;
			
			case 0:
			System.out.println("Bye Bye!");
			break;
			
			default:
			System.out.println("Invalid Choice!\n");
			
		} //switch
		
		} while (choice1 != 0);
		
	}//end main menu
		
//Registring New Employee	   
	public static void RegisterNewEmployee() throws Exception{
		do{
		System.out.println("\t==============================\n");
		System.out.println("\tRegister New Employee \n");
		System.out.println("\t==============================\n");
		System.out.println("\t [1]New Full-Time Employee\n");
		System.out.println("\t [2]New PartTime Employee\n");
		System.out.println("\t [0]Return to Main Menu\n");
			
	
	
		//Enable user input
		Scanner myObj = new Scanner(System.in); 
		System.out.println("Enter Your Choice:");
		num = myObj.nextInt();
		
		//Use Switch Case 
		switch(num){
			case 1:
			EnterFullTimeDet();
			break;
			
			case 2:
			EnterPartTimeDet();
			break;
			
			case 0:
			System.out.println("Bye Bye!");
			break;
			
			default:
			System.out.println("Invalid Choice!\n");
			
		} //switch
		
		} while (num != 0);
}//end registration method	

	public static void ModifyEmployeeDetails() throws Exception{
		do{
		System.out.println("\t==============================\n");
		System.out.println("\tMODIFY DEVELOPER DETAILS\n");
		System.out.println("\t==============================\n");
		System.out.println("\t [1]Edit Full-Time Employee\n");
		System.out.println("\t [2]Edit Part-Time Employee\n");
		System.out.println("\t [3]Return To Main Menu\n");
		
		Scanner myObj = new Scanner(System.in); 
		System.out.println("Enter Your Choice:");
		choiceM = myObj.nextInt();
		
		switch(choiceM){
			case 1:
			EditFullTimeEmployee();
			break;
			
			case 2:
			EditPartTimeEmployee();
			break;
		
			default:
			System.out.println("Invalid Choice!\n");
			
		} //switch

	}while (choiceM != 3);
	}//menu
	public static void EditFullTimeEmployee() throws Exception{
		int x=0, found=0;
		
		System.out.println("\t=============================\n");
		System.out.println("\tEdit Full-Time Employee\n");
		System.out.println("\t=============================\n");
		
		System.out.println("Enter ID To Search: ");
		DeveloperID=myObj.next();
		for(x=0; x<idx; x++){
			if(DeveloperID.equals(ft[x].DeveloperId)){
				found=1;
				break;
			}
		}//SEARCHING 
		if(found==1){
			System.out.println("Full Time Developer ID: " +ft[x].getDeveloperId());
			System.out.println("Full Time Developer Name: " +ft[x].getDeveloperName());
			System.out.println("Full Time Developer Gender: " +ft[x].getgender());
			System.out.println("Full Time Developer Annual Salary: " +ft[x].getAnnualSalary());
			ft[x].DisplayAddressDetails();
			ft[x].DisplayProjectDetails();	
		}//SEARCHING
		
		System.out.println("\t===========================\n");
		System.out.println("\tSELECT AN ITEM TO EDIT\n");
		System.out.println("\t===========================\n");
		

		System.out.println("[1] Full Time Developer Name");
		System.out.println("[2] Full Time Developer Gender ");
		System.out.println("[3] Full Time Developer Annual Salary");
		System.out.println("[4]Full Time Developer Unit No: ");
		System.out.println("[5]Full Time Developer StreetName: ");
		System.out.println("[6]Full Time Developer City: ");
		System.out.println("[7]Full Time Developer Post Code: ");
		System.out.println("Full Time Developer Project ID: ");
		System.out.println("[8]Full Time Developer Client Name: ");
		System.out.println("[9]Full Time Developer Cost: ");
		System.out.println("[0]Return To Modify Menu");
		
		
		System.out.println("\tSELECT AN ITEM TO EDIT\n");
		Scanner myObj = new Scanner(System.in); 
		System.out.println("Enter Your Choice:");
		editFTC = myObj.nextInt();
		
		//Use Switch Case 
		switch(editFTC){
			case 1:
			System.out.print("Enter New Full-Time Developer Name: ");
			newDeveloperName=myObj.next();
			ft[x].setDeveloperName(newDeveloperName);
			break;
			
			case 8:
			System.out.print("Enter New Client Name:");
			newclientName=myObj.next();
			ft[x].editClientName(newclientName);
			break;
			
			case 0:
			break;
		}		
	}//edit
	
	public static void EditPartTimeEmployee() throws Exception{
		System.out.println("\t=============================\n");
		System.out.println("\tEdit Part-Time Employee\n");
		System.out.println("\t=============================\n");
		
	}

	
	public static void MainMenu() throws Exception{
		
		//loadFullTimeDeveloper();
		do{
		System.out.println("\t==================================\n");
		System.out.println("\tWelcome To KDU Developers Firm \n");
		System.out.println("\t==================================\n");
		System.out.println("\t [1]Register New Employee\n");
		System.out.println("\t [2]View Employee's Log\n");
		System.out.println("\t [3]Modify Employee Details\n");
		System.out.println("\t [0]Log Out\n");
		
		//Enable user input
		Scanner myObj = new Scanner(System.in); 
		System.out.println("Enter Your Choice:");
		choice = myObj.nextInt();
		
		//Use Switch Case 
		switch(choice){
			case 1:
			RegisterNewEmployee();
			break;
			
			case 2:
			ViewEmployeeLog();
			break;
			
			case 3:
			ModifyEmployeeDetails();
			break;
			
			case 0:
			System.out.println("Bye Bye!");
			break;
			
			default:
			System.out.println("Invalid Choice!\n");
			
		} //switch
		
		} while (choice != 0);
		
		SaveFullTimeDeveloper();
			
		
		
	}//end main menu
	public static void loadFullTimeDeveloper() throws Exception{
		idx=0;
			FileInputStream fi=new FileInputStream(new File("FullTimers.txt"));
			ObjectInputStream oi=new ObjectInputStream(fi);
			for (idx= 0; idx < oi.available();)
			    ft[idx]=(FullTimeDeveloper)oi.readObject();
			oi.close();
			fi.close();
	}//load full time developer
	
	public static void SaveFullTimeDeveloper() throws Exception{
	FileOutputStream f=new FileOutputStream(new File("FullTimers.txt"));
	ObjectOutputStream o=new ObjectOutputStream(f);
	
	for (int z=0; z<idx; z++){
	//Write Objects to file
	o.writeObject(ft[z]);
	
	}
	o.close();
	f.close();

	}//Save full time developer
	
		public static void main(String args[])throws Exception{
		
		
		//Print Menu
			//Login Function 
	

		String Username;
		String Password;

		Password = "kdu";
		Username = "kdu";

		Scanner input1 = new Scanner(System.in);
		System.out.println("Enter Username : ");
		String username = input1.next();

		Scanner input2 = new Scanner(System.in);
		System.out.println("Enter Password : ");
		String password = input2.next();

		if (username.equals(Username) && password.equals(Password)) {

        System.out.println("Access Granted! Welcome!");
		MainMenu();
		
		}

		else if (username.equals(Username)) {
        System.out.println("Invalid Password!");
		} else if (password.equals(Password)) {
        System.out.println("Invalid Username!");
		} else {
        System.out.println("Invalid Username & Password!");
		}

	}//main
	
}//class


		  