		myObj = new Scanner(System.in);
		System.out.println("Enter Employee ID:");
		EmployeeId = myObj.nextInt(); 
		System.out.println("Enter Developer Name:");
		DeveloperName= myObj.next();
		System.out.println("Enter Employee Address:");
		EmployeeAddress= myObj.nextInt();
		System.out.println("Enter Gender:");